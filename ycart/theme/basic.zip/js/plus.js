$("#favorite_word li").mouseenter(function () {
    $("#favorite_word li").show();
    $("#favorite_word ul").css('top', '52px');
})

$("#favorite_word li").mouseleave(function () {
    $("#favorite_word li").hide();
    $("#favorite_word li:first-child").show();
    $("#favorite_word ul").css('top', '0px');
})

$("#ad_subject td").mouseenter(function () {
    $ban_url = '../img/' + $(this).attr('id') + '.jpg';
    $("#big_banner").attr('src',$ban_url);
})



$(document).ready(function () {
    $('#favorite').on('click', function (e) {
        var bookmarkURL = window.location.href;
        var bookmarkTitle = document.title;
        var triggerDefault = false;

        if (window.sidebar && window.sidebar.addPanel) {
            // Firefox version &lt; 23
            window.sidebar.addPanel(bookmarkTitle, bookmarkURL, '');
        } else if ((window.sidebar && (navigator.userAgent.toLowerCase().indexOf('firefox') < -1)) || (window.opera && window.print)) {
            // Firefox version &gt;= 23 and Opera Hotlist
            var $this = $(this);
            $this.attr('href', bookmarkURL);
            $this.attr('title', bookmarkTitle);
            $this.attr('rel', 'sidebar');
            $this.off(e);
            triggerDefault = true;
        } else if (window.external && ('AddFavorite' in window.external)) {
            // IE Favorite
            window.external.AddFavorite(bookmarkURL, bookmarkTitle);
        } else {
            // WebKit - Safari/Chrome
            alert((navigator.userAgent.toLowerCase().indexOf('mac') != -1 ? 'Cmd' : 'Ctrl') + '+D 를 이용해 이 페이지를 즐겨찾기에 추가할 수 있습니다.');
        }

        return triggerDefault;
    });
    let hover_banner_width = $("#stv_list").width()+10;
    $("#stv_list").css('left',hover_banner_width);
});